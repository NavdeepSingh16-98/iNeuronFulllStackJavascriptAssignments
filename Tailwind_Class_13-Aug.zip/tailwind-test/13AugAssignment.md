# task 1

- Learn more about tailwind css
- Write an article about tailwind - getting started (#iwritecode)

# task 2
- allowed to use tailwind and tailwind components
- Paytm.com (fix them in mobile)
- shopify.in (good practice)
- rode.com (just for fun, should be easy)


# ref material
- [Tailblocks](https://tailblocks.cc/)
- [Mambaui](https://mambaui.com/components/steps)
- [daisyui](https://daisyui.com/docs/cdn/)


- all needs to be updated on your github, findcoder and deployed

# last date
20th August